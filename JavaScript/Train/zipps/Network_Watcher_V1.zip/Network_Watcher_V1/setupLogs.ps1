﻿########################################################################################################################################################################
# This script will persist the provided Azure credential into a local cred file, which will be used by other scripts to retrieve Azure  logs. It also persists
# AzureBlobContainerName and (optionally) Encryption phrase inside azureConfig.ps1
# Syntax:  setupLogs.ps1 AzureStorageAccountName AzureStorageAccountKey 
########################################################################################################################################################################

if ($args.Count -le 1) {
    Write-Host "Syntax: setupLogs.ps1 AzureStorageAccountName AzureStorageAccountKey"
    exit 1
}


. .\azureConfig.ps1
. ${SUMO_SCRIPT_PATH}\sumoUtilLib.ps1






Write-Log "Persisting the credential to file $AZURE_CRED_FILE"
#$encPass = ConvertTo-SecureString -String $args[1] -AsPlainText -Force | ConvertFrom-SecureString -Key $finalByteArray[0..15]
$finalString = $args[0]+":"+$args[1]
Out-File -FilePath ${AZURE_CRED_FILE} -InputObject $finalString
