﻿#######################################################################################################################################################################################
# This script prepares the folder to contain all scripts to collect Azure audit logs
# 
#######################################################################################################################################################################################
if(!(Test-Path  "C:\Program Files\Sumo\powershell\scripts\azure")) {
     New-Item -ItemType directory -Path "C:\Program Files\Sumo\powershell\scripts\azure"    
}
$SUMO_SCRIPT_PATH = "C:\Program Files\Sumo\powershell\scripts\azure"
# test again: 
if(!(Test-Path -PathType Container "C:\Program Files\Sumo\powershell\scripts\azure")) {
    Write-Host "Directory $SUMO_SCRIPT_PATH" not found
    exit 1
}


# Start copying files
Write-Host "Copy files to $SUMO_SCRIPT_PATH"
cp prepareScriptFolder.ps1 "$SUMO_SCRIPT_PATH\."
cp azureConfig.ps1 "$SUMO_SCRIPT_PATH\."
cp setupLogs.ps1 "$SUMO_SCRIPT_PATH\."
cp sumoUtilLib.ps1 "$SUMO_SCRIPT_PATH\."
cp SumoGetLogs.ps1 "$SUMO_SCRIPT_PATH\."


Write-Host "File copy is done. Switching to that folder"
# switch to that folder
#cd $SUMO_SCRIPT_PATH
exit 0
