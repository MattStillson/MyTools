
############################################################################
# TODO : Change the SUMO_URL to your hosted collector URL
#
#############################################################################
$SUMO_URL =""


########################################################################################################
#For Azure Network Watcher, Container name will always be "insights-logs-networksecuritygroupflowevent"
#in all cases, irrespective of azure region
#####################################################################################################
$AZURE_CONTAINER_NAME="insights-logs-networksecuritygroupflowevent"



# THIS IS A FILE CONTAINING ALL ENVIRONMENT PARAMETERS FOR OTHER SCRIPTS

if (!($SUMO_SCRIPT_PATH))  {
    if (Test-Path  "C:\Program Files\Sumo\powershell\scripts\azure") {
        $SUMO_SCRIPT_PATH="C:\Program Files\Sumo\powershell\scripts\azure"            
    } elseif (Test-Path  "C:\Users\sumo") {
        $SUMO_SCRIPT_PATH="C:\Users\sumo"
    } else {
        New-Item -ItemType directory -Path "C:\Program Files\Sumo\powershell\scripts\azure"        
        $SUMO_SCRIPT_PATH="C:\Program Files\Sumo\powershell\scripts\azure"
    }
}


if (!($AZURE_ENC_KEYPHRASE)) {
    # The following is required to encrypt the provided credential
    $AZURE_ENC_KEYPHRASE="This is a super secret password"
}

if (!($AZURE_BLOB_READ_PATH)) {
    $AZURE_BLOB_READ_PATH="${SUMO_SCRIPT_PATH}\blobs_read.txt"
}

if (!($AZURE_ALL_BLOBS_PATH)) {
    $AZURE_ALL_BLOBS_PATH="${SUMO_SCRIPT_PATH}\all_blobs_in_container.txt"
}

if (!($en)) {
    $AZURE_BLOBS_NEED_TO_BE_DOWNLOADED="${SUMO_SCRIPT_PATH}\blobs_need_to_be_downloaded.txt"
}

if (!($AZURE_PULL_OLD_BLOBS_DAYS)) {
    $AZURE_PULL_OLD_BLOBS_DAYS= 0

}

if ($AZURE_CRED_FILE -eq $null) {
    $AZURE_CRED_FILE="${SUMO_SCRIPT_PATH}\cred.txt"
}



# setting up flag to false, this will be set to true once the script run for the fist time

if(([Environment]::GetEnvironmentVariable("FirstTimeRunFlag","User")) -lt 0) {

[Environment]::SetEnvironmentVariable("FirstTimeRunFlag", "false", "User")


}


