var Promise = function () {
	this.done = function (fn) {
	};

	this.failed = function (fn) {
	};

	this.resolve = function (result) {
	};

	this.fail = function (reason) {
	};
};

module.exports = Promise;