﻿# UTILITY LIBRARY 
 . "$PSScriptRoot\azureConfig.ps1"

function Write-Log ([String] $Message, [String] $Level = "INFO",[String] $DateFormat="yyyy-MM-ddTHH:mm:sszzz" ) {
    $dateString = (Get-Date).ToString($DateFormat)    
    if ($Level.ToUpper() -eq "DEBUG") {
        Write-Debug "DEBUG: $dateString - $Message"
    } elseif (($Level.ToUpper() -eq "WARNING") -or ($Level.ToUpper() -eq "WARN")){
        Write-Warning "$dateString - $Message"
    } elseif ($Level.ToUpper() -eq "VERBOSE") {
        Write-Verbose "VERBOSE: $dateString - $Message"
    } elseif ($Level.ToUpper() -eq "ERROR") {
        Write-Error "$dateString - $Message"
    } else {        
        Write-Host "INFO: $dateString - $Message"
    }
}



################################################################################################################
# Here: This function converts log files from Storage/container in to Json format and send it over to SumoLogic
# hosted collector
#################################################################################################################
function BlobToJson ([String] $BLOB)
{
	
	$body = Get-Content $env:Temp/$BLOB -Raw
	$record = $body | Convertfrom-Json
	$record.records.Count
	For  ($j=0; $j -lt $record.records.Count; $j++) {
	
	 For  ($i=0; $i -lt $record.records[$j].properties.flows.Count; $i++){
	
	   $tuple = $record.records[$j].properties.flows[$i].flows.flowtuples
	  
		For  ($k=0; $k -lt $tuple.count; $k++) {
            $splitted_tuple = $tuple[$k] -split ','
	       if ($splitted_tuple[5]){
                 $body = @{
	                   time = $record.records[$j].time;
	                   sys_id = $record.records[$j].systemId;
	                   category = $record.records[$j].category;
	                   resource_id =  $record.records[$j].resourceId;
	                   event_name = $record.records[$j].operationName;
	                   rule_name = $record.records[$j].properties.flows[$i].rule;
	                   mac = $record.records[$j].properties.flows[$i].flows.mac;
	                   src_ip = $splitted_tuple[1];
	                   dest_IP = $splitted_tuple[2];
	                   src_port = $splitted_tuple[3];
	                   dest_port = $splitted_tuple[4];
	                   protocol = $splitted_tuple[5];
	                   traffic_destination = $splitted_tuple[6];
	                   "traffic_a/d" = $splitted_tuple[7]
   	                 }

            $msg = $body | ConvertTo-Json -Compress
	        $output = Invoke-WebRequest -Uri $SUMO_URL -Method POST -Body  $msg


        }

	       


	       }
	 }

	}
}


