﻿#######################################################################################################################################################################################
# This script is the main setup script called by the Azure VMExtension
# Syntax: initSetup.ps1 <AzureStorageAccountName> <AzureStorageAccountKey> 
#######################################################################################################################################################################################

if ($args.Count -lt 2) {
    Write-Host "initSetup.ps1  <AzureStorageAccountName> <AzureStorageAccountKey> "
    exit 1
}
.\prepareScriptFolder.ps1
if ($LASTEXITCODE -eq 0) {
    # setup credential, persist environment parameters like 
    .\setupLogs $args[0] $args[1]
   
}

