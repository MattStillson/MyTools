﻿
# Include all the user defined varaibles
. "$PSScriptRoot\azureConfig.ps1"
. "$PSScriptRoot\sumoUtilLib.ps1"

try{

    ###########################################################################################################
    #                      Connection string to call Azure Storage Commands
    #
    ###########################################################################################################

   
    $content  = Get-Content $AZURE_CRED_FILE 
    $index = $content.IndexOf(":")
    $StorageAccountName =$content.Substring(0,$index)
    $StorageAccountKey = $content.Substring($index+1)
   
	$Ctx = New-AzureStorageContext -StorageAccountName $StorageAccountName -StorageAccountKey $StorageAccountKey

    ###########################################################################################################
    #  Create an empty blob_read.txt file for the first time
    #
    ###########################################################################################################


    if (!(Test-Path $AZURE_BLOB_READ_PATH))
    {
     New-Item -path $AZURE_BLOB_READ_PATH -type "file" -value "#File_name`r`n"
     Write-Host "Created empty blobs_read.txt"
    }

    $date = Get-Date 
    ####################################################################################### 
    #    Here we are listing all the Blobs in the Container  
    # Enhancement TODO : Possibly have a Foor loop to download the blobs from container
    # Especially when there tonnes of Blobs in container, avoid downloading all in once                                                             
    #######################################################################################
	$blobs_list_in_container  =  Get-AzureStorageBlob -Container $AZURE_CONTAINER_NAME -Context $Ctx 
	$blobs_list_in_container.Name  | Out-File $AZURE_ALL_BLOBS_PATH
    

    ###########################################################################################################
    #  Executed only once in life time
    #
    ###########################################################################################################


    
    if(([Environment]::GetEnvironmentVariable("FirstTimeRunFlag","User")) -eq "false")
    {
        "SumoGetLogs :: It's a First Time Run, setting up Env Variable FirstTimeRunFlag to true "
        
        [Environment]::SetEnvironmentVariable("FirstTimeRunFlag", "true", "User")
        Get-Content $AZURE_ALL_BLOBS_PATH  | Set-Content  $env:Temp/temp_blobs.txt
        Get-Content $AZURE_ALL_BLOBS_PATH  | Set-Content $AZURE_BLOB_READ_PATH
        $AZURE_PULL_OLD_BLOBS_DAYS

        For ($i=$AZURE_PULL_OLD_BLOBS_DAYS; $i -lt 0; $i++) {
            $pattern_to_match = "/y=" + $date.AddDays($i).Year+"/m="+($date.AddDays($i).Month).ToString("00")+"/d="+($date.AddDays($i).Day).ToString("00") +"/"
            $i
            "SumoGetLogs :: Inside First time for loop. Removing Pattern from all_blobs.txt and copying to read_blobs.txt " + $pattern_to_match
            Get-Content  $env:Temp/temp_blobs.txt | Where-Object { $_ -notmatch ($pattern_to_match)} | Set-Content $AZURE_BLOB_READ_PATH
            Get-Content $AZURE_BLOB_READ_PATH  | Set-Content $env:Temp/temp_blobs.txt

        }

    }


    ######################################################################################################################################################################
    #Blobs are stored in container in following format :
    # <appName>/YYYY/MM/DD/HH/logFileName, e.g - :resourceId=/SUBSCRIPTIONS/AZURELABS/PROVIDERS/MICROSOFT.NETWORK/NETWORKSECURITYGROUPS/NSG/y=2017/m=02/d=20/h=20/m=00/PT1H.json
    #                                          - SAMPLEECOMME/2016/05/19/21/1f9ffd.log
    # Here: We will create a regex log string in same format as above, this string will be used to extract
    # all the log blobs from the last hour [a-zA-Z0-9-]+\/y=2017\/m=02\/d=02\/h=0\/m=00\/[\w-.]+.[a-z]+
    #############################################################################################################################################################################
	$log_string =  "[a-zA-Z0-9-=/.]+" + "\/y=" + $date.Year+"\/m="+($date.Month).ToString("00")+"\/d="+($date.Day).ToString("00")+"\/h="+($date.Hour-1).ToString("00")
	$string_to_match = $log_string +'\/m=00\/[\w-.]+.json'
	"SumoGetLogs :: This is the string to match for blob to downloand :" + $string_to_match

	$blobs_in_container = Get-Content $AZURE_ALL_BLOBS_PATH


    ########################################################################################################
    # Here was using regex match to extract all the log blobs from the last hour. We are matching log string
    # to the output of list container. $blob_files, an array, will contain all the log blob names from the
    # last hour
    #######################################################################################################


    #This will be replaced, Word array has all the files we need to pull down
	$blob_files = ([regex]::matches($blobs_in_container, "($string_to_match)") | %{$_.value})
	"SumoGetLogs :: I am going to download these blobs Files :" + $blob_files

    #########################################################################################################
    # Here: we are looping through the array, and for each blob file we are downloading the log file
    # and stdout-ing the logs/dumping logs to Sumo's http source. stdout content will be picked up
    # Sumo's installed collector. After we are done with blob log files, we are deleting them
    #######################################################################################################
	
    
    ForEach  ($blob in $blob_files) {
		Get-AzureStorageBlobContent -Container $AZURE_CONTAINER_NAME -Context $Ctx -Blob $blob -Destination $env:Temp
		Add-Content $AZURE_BLOB_READ_PATH $blob
		BlobToJson($blob)
		Remove-Item $env:Temp/$blob
      
	}

   
    #############################################################################################################
    # Here: We are comparing two files: 1. All Blobs in container 2.Blobs read up till now. 
    # All blobs in container are stored in all_blobs_in_container.txt
    # All blobs which are downloaded and Read are tracked in blobs_read.txt
    # Blobs which are not read and exist in all_blobs_in_container are stored in blobs_need_to_be_downloaded.txt
    ##############################################################################################################

    $compared_object =   Compare-Object $(Get-Content $AZURE_ALL_BLOBS_PATH)   $(Get-Content $AZURE_BLOB_READ_PATH) | where {$_.SideIndicator -eq "<="}
    $compared_object.InputObject |  Out-File $AZURE_BLOBS_NEED_TO_BE_DOWNLOADED
 

    #########################################################################################################
    # Here: Looping through each blob list which is un-read and needs to be downloaded
    # After downloading unread blob(s), they need to be marked as Read in blobs_read.txt
    #######################################################################################################
    ForEach  ($download_blob in $compared_object.InputObject)
     {
        $string_match = "[a-zA-Z0-9-]+" + "\/" + $date.Year+"\/"+($date.Month).ToString("00")+"\/"+($date.Day).ToString("00")+"\/"+($date.Hour).ToString("00") +'\/[\w-.]+.[a-z]+'
        "This is the string for blob NOT to download ::" + $string_match
        
        #It may download the blobs which were recently created this hour and are still being written, so we need to avoid downloading those files.
        if ( -Not ($download_blob -match $string_match )) 
        {       
            Get-AzureStorageBlobContent -Container $AZURE_CONTAINER_NAME -Context $Ctx -Blob $download_blob -Destination $env:Temp
            BlobToJson($download_blob)
            "SumoGetLogs :: SanityCheck - I am going to download these blobs Files :" + $download_blob
  
            #Marking blob as Read in blobs_read.txt
            Add-Content $AZURE_BLOB_READ_PATH $download_blob
            Remove-Item $env:Temp/$download_blob  
        }
     
      }

}

    catch [System.Exception] {  
	    Write-Host "Got exception : " $error.Exception      
}







