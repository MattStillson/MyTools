﻿var foo = 5;

function storeSettings() {
    alert('Storing settings');
}